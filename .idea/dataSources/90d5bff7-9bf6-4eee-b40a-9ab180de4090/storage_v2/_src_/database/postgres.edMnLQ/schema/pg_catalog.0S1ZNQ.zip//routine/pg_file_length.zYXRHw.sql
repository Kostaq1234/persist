create function pg_file_length(text) returns bigint
    strict
    language sql
as
$$
SELECT size FROM pg_catalog.pg_stat_file($1)
$$;

alter function pg_file_length(text) owner to postgres;

